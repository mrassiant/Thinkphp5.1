<?php /*a:3:{s:65:"D:\phpstudy_pro\WWW\tp5\application\admin\view\set\user\info.html";i:1621758270;s:65:"D:\phpstudy_pro\WWW\tp5\application\admin\view\common\header.html";i:1621690964;s:65:"D:\phpstudy_pro\WWW\tp5\application\admin\view\common\footer.html";i:1621757172;}*/ ?>

<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8" />
    <title>网站后台管理系统</title>
    <meta name="renderer" content="webkit" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
    <meta
      name="viewport"
      content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=0"
    />

    <link rel="stylesheet" type="text/css" href="/static/admin/layuiadmin/layui/css/layui.css" /><link rel="stylesheet" type="text/css" href="/static/admin/layuiadmin/style/admin.css" />
  </head>
</html>

<body>

  <div class="layui-fluid">
    <div class="layui-row layui-col-space15">
      <div class="layui-col-md12">
        <div class="layui-card">
          <div class="layui-card-header">设置我的资料</div>
          <div class="layui-card-body" pad15>
            
            <div class="layui-form" lay-filter="">

              <div class="layui-form-item" style="display:none;">
                
                <div class="layui-input-inline">
                  <input type="text" name="id" value="<?php echo htmlentities($userinfo['id']); ?>" readonly class="layui-input" disabled>
                </div>
               
              </div>




              <div class="layui-form-item">
                <label class="layui-form-label">我的角色</label>
                <div class="layui-input-inline">
                  <select name="role" lay-verify="">
                    <option value="1" selected>超级管理员</option>
                    <option value="2" >普通管理员</option>
                    <option value="3" >审核员</option>
                    <option value="4" >编辑人员</option>
                  </select> 
                </div>
                <div class="layui-form-mid layui-word-aux">当前角色不可更改为其它角色</div>
              </div>
              <div class="layui-form-item">
                <label class="layui-form-label">用户名</label>
                <div class="layui-input-inline">
                  <input type="text" name="name" value="<?php echo htmlentities($userinfo['name']); ?>" readonly class="layui-input" disabled>
                </div>
                <div class="layui-form-mid layui-word-aux">不可修改。一般用于后台登入名</div>
              </div>
              <div class="layui-form-item">
                <label class="layui-form-label">昵称</label>
                <div class="layui-input-inline">
                  <input type="text" name="nickname" value="<?php echo htmlentities($userinfo['nickname']); ?>" lay-verify="nickname" autocomplete="off" placeholder="请输入昵称" class="layui-input">
                </div>
              </div>
              <div class="layui-form-item">
                <label class="layui-form-label">性别</label>
                <div class="layui-input-block">
                 <?php if($userinfo['sex'] == 1): ?>
                  <input type="radio" name="sex" value="1" title="男" checked>
                  <input type="radio" name="sex" value="2" title="女" >
                  <?php else: ?>
                  <input type="radio" name="sex" value="1" title="男" >
                  <input type="radio" name="sex" value="2" title="女" checked>
                  <?php endif; ?>
                </div>
              </div>
             
              <div class="layui-form-item">
                <label class="layui-form-label">手机</label>
                <div class="layui-input-inline">
                  <input type="text" name="mobile" value="<?php echo htmlentities($userinfo['mobile']); ?>" lay-verify="phone" autocomplete="off" class="layui-input">
                </div>
              </div>
              <div class="layui-form-item">
                <label class="layui-form-label">邮箱</label>
                <div class="layui-input-inline">
                  <input type="text" name="email" value="<?php echo htmlentities($userinfo['email']); ?>" lay-verify="email" autocomplete="off" class="layui-input">
                </div>
              </div>
              <div class="layui-form-item layui-form-text">
                <label class="layui-form-label">备注</label>
                <div class="layui-input-block">
                  <textarea name="info" placeholder="请输入内容" class="layui-textarea"><?php echo htmlentities($userinfo['info']); ?></textarea>
                </div>
              </div>
              <div class="layui-form-item">
                <div class="layui-input-block">
                  <button class="layui-btn" lay-submit lay-filter="setmyinfo">确认修改</button>
                  <!-- <button type="reset" class="layui-btn layui-btn-primary">重新填写</button> -->
                </div>
              </div>
            </div>
            
          </div>
        </div>
      </div>
    </div>
  </div>

  <!-- <script src="../../../layuiadmin/layui/layui.js"></script>   -->

<script type="text/javascript" src="/static/admin/layuiadmin/layui/layui.js"></script>

<script>
  var upuri = "<?php echo url('admin/Upload/upload'); ?>"
  var weburi = "<?php echo url('admin/Upload/update'); ?>"
  var infouri = "<?php echo url('admin/User/update'); ?>"
  var newsuri = "<?php echo url('admin/News/getdata'); ?>"
  var logout = "<?php echo url('admin/Login/logout'); ?>"
</script>


  <script>
  layui.config({
    base: '/static/admin/layuiadmin/' //静态资源所在路径
  }).extend({
    index: 'lib/index' //主入口模块
  }).use(['index', 'set']);
  </script>
</body>
</html>