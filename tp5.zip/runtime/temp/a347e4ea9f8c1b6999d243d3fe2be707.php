<?php /*a:3:{s:65:"D:\phpstudy_pro\WWW\tp5\application\admin\view\home\homeland.html";i:1621756783;s:65:"D:\phpstudy_pro\WWW\tp5\application\admin\view\common\header.html";i:1621690964;s:65:"D:\phpstudy_pro\WWW\tp5\application\admin\view\common\footer.html";i:1621757172;}*/ ?>

<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8" />
    <title>网站后台管理系统</title>
    <meta name="renderer" content="webkit" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
    <meta
      name="viewport"
      content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=0"
    />

    <link rel="stylesheet" type="text/css" href="/static/admin/layuiadmin/layui/css/layui.css" /><link rel="stylesheet" type="text/css" href="/static/admin/layuiadmin/style/admin.css" />
  </head>
</html>

<body>

  <div class="layui-fluid">
    <div class="layui-row layui-col-space15">
      <div class="layui-col-md12">
        <div class="layui-card">
          <div class="layui-card-header">网站设置</div>
          <div class="layui-card-body" pad15>
            
            <div class="layui-form" wid100 lay-filter="">
              <div class="layui-form-item">
                <label class="layui-form-label">网站名称</label>
                <div class="layui-input-block">
                  <input type="text" name="web_name" value="<?php echo htmlentities($webinfo->web_name); ?>" class="layui-input">
                </div>
              </div>
              <div class="layui-form-item">
                <label class="layui-form-label">网站域名</label>
                <div class="layui-input-block">
                  <input type="text" name="web_host" lay-verify="url" value="<?php echo htmlentities($webinfo->web_host); ?>" class="layui-input">
                </div>
              </div>
              <div class="layui-form-item">
                <label class="layui-form-label">缓存时间</label>
                <div class="layui-input-inline" style="width: 80px;">
                  <input type="text" name="web_cache" lay-verify="number" value="<?php echo htmlentities($webinfo->web_cache); ?>" class="layui-input">
                </div>
                <div class="layui-input-inline layui-input-company">分钟</div>
                <div class="layui-form-mid layui-word-aux">本地开发一般推荐设置为 0，线上环境建议设置为 10。</div>
              </div>
              <div class="layui-form-item">
                <label class="layui-form-label">最大文件上传</label>
                <div class="layui-input-inline" style="width: 80px;">
                  <input type="text" name="web_upsize" lay-verify="number" value="<?php echo htmlentities($webinfo->web_upsize); ?>" class="layui-input">
                </div>
                <div class="layui-input-inline layui-input-company">KB</div>
                <div class="layui-form-mid layui-word-aux">提示：1 M = 1024 KB</div>
              </div>
              <div class="layui-form-item">
                <label class="layui-form-label">上传文件类型</label>
                <div class="layui-input-block">
                  <input type="text" name="web_filetype" value="<?php echo htmlentities($webinfo->web_filetype); ?>" class="layui-input">
                </div>
              </div>
              
              <div class="layui-form-item layui-form-text">
                <label class="layui-form-label">首页标题</label>
                <div class="layui-input-block">
                  <textarea name="web_title" class="layui-textarea"><?php echo htmlentities($webinfo->web_title); ?></textarea>
                </div>
              </div>
              <div class="layui-form-item layui-form-text">
                <label class="layui-form-label">关键词</label>
                <div class="layui-input-block">
                  <textarea name="web_keywords" class="layui-textarea" placeholder="多个关键词用英文状态 , 号分割"><?php echo htmlentities($webinfo->web_keywords); ?></textarea>
                </div>
              </div>
              <div class="layui-form-item layui-form-text">
                <label class="layui-form-label">META描述</label>
                <div class="layui-input-block">
                  <textarea name="web_desc" class="layui-textarea"><?php echo htmlentities($webinfo->web_desc); ?></textarea>
                </div>
              </div>
              <div class="layui-form-item layui-form-text">
                <label class="layui-form-label">版权信息</label>
                <div class="layui-input-block">
                  <textarea name="web_copyright" class="layui-textarea"><?php echo htmlentities($webinfo->web_copyright); ?></textarea>
                </div>
              </div>

              <div class="layui-form-item">
               <label class="layui-form-label">网站logo</label>
               <div class="layui-input-inline">
                 <input name="web_logo" lay-verify="required" id="LAY_avatarSrc" placeholder="图片地址"  class="layui-input" value="<?php echo htmlentities($webinfo->web_logo); ?>"> 
               </div>
               <div class="layui-input-inline layui-btn-container" style="width: auto;">
                 <button type="button" class="layui-btn layui-btn-primary" id="LAY_avatarUpload">
                   <i class="layui-icon">&#xe67c;</i>上传图片
                 </button>
                 <button class="layui-btn layui-btn-primary" layadmin-event="avartatPreview">查看图片</button >
               </div>
            </div>






              <div class="layui-form-item">
                <div class="layui-input-block">
                  <button class="layui-btn" lay-submit lay-filter="set_website">确认保存</button>
                </div>
              </div>
            </div>
            
          </div>
        </div>
      </div>
    </div>
  </div>

  <!-- <script src="../../../layuiadmin/layui/layui.js"></script>   -->

  <script type="text/javascript" src="/static/admin/layuiadmin/layui/layui.js"></script>

  <script>
  var upuri = "<?php echo url('admin/Upload/upload'); ?>"
  var weburi = "<?php echo url('admin/Upload/update'); ?>"
  var infouri = "<?php echo url('admin/User/update'); ?>"
  var newsuri = "<?php echo url('admin/News/getdata'); ?>"
  var logout = "<?php echo url('admin/Login/logout'); ?>"
</script>

  <script>
   
  layui.config({
    base: '/static/admin/layuiadmin/' //静态资源所在路径
  }).extend({
    index: 'lib/index' //主入口模块
  }).use(['index', 'set']);
  </script>
</body>
</html>